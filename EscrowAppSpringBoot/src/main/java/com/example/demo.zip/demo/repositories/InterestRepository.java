package com.example.demo.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Interest;
import com.example.demo.entities.Vehicle;
@Repository
public interface InterestRepository extends JpaRepository<Interest, Integer> {
	 List<Interest> findByVehicle_VehicleId(int vehicleId);
	// Vehicle findByBuyer_BId(int buyer);
	 //Optional<Interest> findByBuyer_BId(int bId);
	// List<Interest> findByBuyer_BId(int bId);
}

