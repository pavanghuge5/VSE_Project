package com.example.demo.services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.entities.Interest;
import com.example.demo.entities.Vehicle;
import com.example.demo.repositories.InterestRepository;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class InterestService {
    @Autowired
    private InterestRepository interestRepository;

   
    
}
